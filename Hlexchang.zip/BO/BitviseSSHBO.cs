﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HitleapExchange.BO
{
    class BitviseSSHBO
    {
        public string host;
        public string port = "22";
        public string user;
        public string pass;
        public string c2sConfig;
        public BitviseSSHBO()
        {
            c2sConfig = "127.2.0.1,8084,bubblews.com,80";
        }
    }
}
