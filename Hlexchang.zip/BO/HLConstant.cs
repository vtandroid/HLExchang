﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HitleapExchange.BO
{
   static class HLConstant
    {
        public static string URL_LOGIN = "http://hitleap.com/log-in";
        public static string URL_SENDLOGIN = "http://hitleap.com/log-in";
        public static string URL_EXCHANGE = "http://hitleap.com/traffic-exchange";
        public static string URL_CHUNK = "http://hitleap.com/get-chunks";
        public static string URL_REWEECSS = "http://rewee.info/clk-css.css?hash=";
        public static string URL_REFER = "http://hitleap.com/traffic-exchange";
        public static string DATA_CHUNK = "chunks=nn";
        public static string XRequestedWith = "XMLHttpRequest";
        public static string URL_HOME = "http://hitleap.com";
        public static int TIMES_TO_RESET = 100;
        public static int MAX_COUNT_PROXY = 100;
        public static string PORT_DEFAULT_PROXY = "8084";
        public static string PORT_DEFAULT_SSH = "22";
        public static string PORT_DEFAULT_WEB = "80";
    }
}
