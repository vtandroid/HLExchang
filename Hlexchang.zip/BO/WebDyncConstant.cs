﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HitleapExchange.BO
{
    static class WebDyncConstant
    {
        public static string URL_GET_RDI_LOGIN = "http://www.websyndic.com/wv3/";
        public static string URL_LOGIN_1 = "http://www.websyndic.com/wv3/cc.php";
        public static string URL_LOGIN_2 = "http://www.websyndic.com/wv3/?p=home";
        public static string URL_GET_LINK_SURF = "http://www.websyndic.com/wv3/?p=visio01";
        public static string URL_TARGET = "http://www.websyndic.com/wv3/target.php";
        public static string URL_VALID_SURF = "http://www.websyndic.com/wv3/valid_surf.php";
        public static string XRequestedWith = "XMLHttpRequest";
        public static int TIMES_TO_RESET = 100;
        public static int MAX_COUNT_PROXY = 100;
        public static string PORT_DEFAULT_PROXY = "8084";
        public static string PORT_DEFAULT_SSH = "22";
        public static string PORT_DEFAULT_WEB = "80";
    }
}
