﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

namespace HitleapExchange.BO
{
    class HitLeapBO
    {
        public string proxy;
        public string username;
        public string password;
        public string athuKey;
        public string XCSRFToken;
        public string dataChunk;
        public WebRequestConfig webRequestConfig;
        public HitLeapBO(string userName,string passWord="null",string proxy=null)
        {
            this.username = userName;
            this.password = passWord;
            this.proxy = proxy;
            webRequestConfig = new WebRequestConfig();
            webRequestConfig.proxy = proxy;
            dataChunk = "chunks=nn";
        }
    }
}
