﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

namespace HitleapExchange.BO
{
    class WebRequestConfig
    {
        public string Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
        public string HitleapViewerOsVersion="6.1";
        public string HitleapViewerVersion="2.8";
        public string UserAgent="HitLeap Viewer 2.8";
        public string Referer="http://hitleap.com/traffic-exchange";
        public string AcceptEncoding="gzip,deflate";
        public string AcceptLanguage="en-us,en";
        public string AcceptCharset = "UTF-8";
        public string method = "GET";
        public string proxy;
        public string Origin;
        public  CookieContainer cookieContainer = new CookieContainer();
        public string XCSRFToken;
        public string XRequestedWith;
        public string HitleapUsername;
        public string ContentType;
    }
}
