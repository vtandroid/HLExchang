﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HitleapExchange.BO
{
    class WebSiteSurf
    {
        public String address;
        public int timer;
    }
}
