﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HitleapExchange.BO;
using System.Threading;
namespace HitleapExchange.DAO
{
   static class ResetThread
    {
       //public static HitleapDAO hitleapDAO;
       public static object obj1lock="";

       public static void setResetThread(HitleapDAO hitleapDAO)
       {
           lock (obj1lock)
           {
               if (hitleapDAO.logDAO.countReset < HLConstant.TIMES_TO_RESET)
               {
                   hitleapDAO.logDAO.countReset++;
                  
                   if (hitleapDAO.logDAO.isErrorExchange())
                   {
                       hitleapDAO.logDAO.setDefault();
                       Thread t = new Thread(hitleapDAO.RunExchange);
                       t.Start();
                       Thread.Sleep(1);
                   }
                   else
                   {
                       hitleapDAO.logDAO.setDefault();
                       Thread t = new Thread(hitleapDAO.Run);
                       t.Start();
                       Thread.Sleep(1);
                   }
               }
               else
               {
                   //ProxyDAO pr = new ProxyDAO();
                   //hitleapDAO.hitleapBO.proxy = pr.getProxy();
                   Thread.Sleep(1000);
                   BitviseSSHManager.getInstance().ResetBitvise(hitleapDAO.indexReset);
                   hitleapDAO.logDAO.countReset=0;
                   HLConstant.TIMES_TO_RESET = 100;
                   hitleapDAO.logDAO.setDefault();
                   Thread t = new Thread(hitleapDAO.Run);
                   t.Start();
                  
               }
           }
       }
    }
}
