﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HitleapExchange.DAO
{
    class LogDAO
    {
        public  List<string> logError=new List<string>();
        public string logEarn = "";
        public Boolean logPenza = true;
        public int countReset = 0;
        public void LogError(string message)
        {
            if (logError.Count > 50000)
                logError.Clear();
            logError.Add(message);
        }
        public void setDefault()
        {
            logError.Clear();
            logEarn = "";
            logPenza = true;
        }
        public Boolean isErrorExchange()
        {
            if (logError.Count < 1)
                return false;
            return (logError[logError.Count - 1].IndexOf("[Error][Exchange]") >= 0);
        }
        public Boolean isErrorLogin()
        {
            if (logError.Count < 1)
                return false;
            return ((logError[logError.Count - 1].IndexOf("[Error][Get Login Token]") >= 0) || (logError[logError.Count - 1].IndexOf("[Error][Send Request Login]") >= 0));
        }
    }
}
