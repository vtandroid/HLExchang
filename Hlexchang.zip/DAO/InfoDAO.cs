﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HitleapExchange.BO;
using System.IO;
namespace HitleapExchange.DAO
{
    class InfoDAO
    {
        public List<HitLeapBO> GetDataHitleap()
        {
            RequestHelper r = new RequestHelper();
            r.CreateRequest("http://bigdata.1apps.com/data/testjson/Resource.html");
            string respone = r.GetRequest();
            string[] arrUser = respone.Split('|');
            List<HitLeapBO> lstHitleapBO = new List<HitLeapBO>();
            ProxyDAO pr= new ProxyDAO();
            for (int i = 0; i < arrUser.Length; i++)
            {
                HitLeapBO hitleapBO = new HitLeapBO(arrUser[i].Trim(), "kiemtienthoi", pr.getProxy());
                lstHitleapBO.Add(hitleapBO);
            }
            return lstHitleapBO;
        }
        public List<HitLeapBO> GetDataHitleapForSSH()
        {
            RequestHelper r = new RequestHelper();
            r.CreateRequest("http://bigdata.1apps.com/data/testjson/Resource.html");
            string respone = r.GetRequest();
            string[] arrUser = respone.Split('|');
            List<HitLeapBO> lstHitleapBO = new List<HitLeapBO>();
            List<string> lstconfig = GetConfigSSH();
            string proxy="";
            foreach (string item in lstconfig)
            {
                if (item.IndexOf("hitleap") >= 0)
                    proxy = item.Split('|')[0];
            }
            for (int i = 0; i < arrUser.Length; i++)
            {
                HitLeapBO hitleapBO = new HitLeapBO(arrUser[i].Trim(), "kiemtienthoi", proxy+(i+1).ToString()+":"+ HLConstant.PORT_DEFAULT_PROXY);
                lstHitleapBO.Add(hitleapBO);
            }
            return lstHitleapBO;
        }
        public List<string> GetConfigSSH()
        {
            RequestHelper r = new RequestHelper();
            r.CreateRequest("http://bigdata.1apps.com/data/testjson/Config.html");
            string respone = r.GetRequest();
            List<string> lstResult = new List<string>();
            string[] result = respone.Split('@');
            for (int i = 0; i < result.Length; i++)
            {
                string[] temp = result[i].Split('|');
                string resul1="";
                if (char.IsDigit(temp[0], 0))
                {
                    resul1 = "127." + temp[0].ToString() + ".0.";
                    resul1 +="|"+ temp[1];
                }
                else
                {
                    resul1 = "127." + temp[1].ToString() + ".0.";
                    resul1 +="|"+ temp[0];
                }
                lstResult.Add(resul1);

            }
            return lstResult;
        }
        public List<string> GetConfigSSHFolder()
        {
            List<string> lstResult = new List<string>();
            string input = null;
            List<string> ListResultTemp = new List<string>();
            using (StreamReader reader = new StreamReader("Config.txt"))
            {
                while ((input = reader.ReadLine()) != null)
                {
                    ListResultTemp.Add(input);
                }
            }
            for (int i = 0; i < ListResultTemp.Count; i++)
            {
                string[] temp = ListResultTemp[i].Split('|');
                string resul1 = "";
                if (char.IsDigit(temp[0], 0))
                {
                    resul1 = "127." + temp[0].ToString() + ".0.";
                    resul1 += "|" + temp[1];
                }
                else
                {
                    resul1 = "127." + temp[1].ToString() + ".0.";
                    resul1 += "|" + temp[0];
                }
                lstResult.Add(resul1);

            }
            return lstResult;
        }
        public List<HitLeapBO> GetDataHitleapForSSHFolder()
        {
            string input = null;
            List<string> ListUser = new List<string>();
            using (StreamReader reader = new StreamReader("Resource.txt"))
            {
                while ((input = reader.ReadLine()) != null)
                {
                    ListUser.Add(input);
                }
            }
            List<HitLeapBO> lstHitleapBO = new List<HitLeapBO>();
            List<string> lstconfig = GetConfigSSHFolder();
            string proxy = "";
            foreach (string item in lstconfig)
            {
                if (item.IndexOf("hitleap") >= 0)
                    proxy = item.Split('|')[0];
            }
            for (int i = 0; i < ListUser.Count; i++)
            {
                HitLeapBO hitleapBO = new HitLeapBO(ListUser[i].Trim(), "kiemtienthoi", proxy + (i + 1).ToString() + ":" + HLConstant.PORT_DEFAULT_PROXY);
                lstHitleapBO.Add(hitleapBO);
            }
            return lstHitleapBO;
        }
        public List<string> GetListSSHFromFolder()
        {
            string input=null;
            List<string> ListSSH=new List<string>();
             using (StreamReader reader = new StreamReader("SSH.txt"))
                {
                    while ((input = reader.ReadLine()) != null)
                    {
                        ListSSH.Add(input);
                    }
                }
            return ListSSH;
        }
    }
}
