﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
namespace HitleapExchange.DAO
{
    class RequestHelperExtend : RequestHelper
    {
        public void addHeader(string header)
        {
            try
            {
                strWebHeaderConfig = header;
            }
            catch
            { }
        }
        public void setProxy(string proxy)
        {
            try
            {
                WebProxy myProxy = new WebProxy(proxy);
                rq.Proxy = myProxy;
            }
            catch { }
        }
    }
}
