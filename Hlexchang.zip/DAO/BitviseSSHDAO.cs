﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Windows.Forms;
using HitleapExchange.BO;
namespace HitleapExchange.DAO
{
    class BitviseSSHDAO
    {
        public BitviseSSHBO bitviseSSHBO= new BitviseSSHBO();
        Process Bitvise;
        public void setBitviseSSHBO(BitviseSSHBO b)
        {
            bitviseSSHBO = b;
        }
        public void CreateBitvise()
        {
            string[] s = { bitviseSSHBO.host, bitviseSSHBO.user, bitviseSSHBO.pass };
          //string comand = "-profile=\"" + Application.StartupPath + "\\Bitvise SSH Client\\x.bscp\" -host=" + s[0] + " -port=22 -user=" + s[1] + " -password=" + s[2] + " -loginOnStartup -exitOnLogout -openTerm=n -c2sAccept=y -c2s=127.2.0." + i.ToString() + ",8084,bubblews.com,80,127.4.0." + i.ToString() + ",8084,backoffice.anuntiomatic.com,80,127.4.1." + i.ToString() + ",8084,aweber.com,80,127.5.0." + i.ToString() + ",8084,unitedworldbux.com,80,127.7.0." + i.ToString() + ",8084,ptcircle.com,80";
            string comand = "-profile=\"" + Application.StartupPath + "\\Bitvise SSH Client\\x.bscp\" -host=" + s[0] + " -port=22 -user=" + s[1] + " -password=" + s[2] + " -loginOnStartup -exitOnLogout -openTerm=n -openSFTP=n -openRDP=n -menu=small -hide=banner,auth,popups,trayLog,trayPopups,trayIcon -c2sAccept=y -c2s=" + bitviseSSHBO.c2sConfig;
             Bitvise = Process.Start(Application.StartupPath + @"\Bitvise SSH Client\BvSsh.exe", comand);
        }
        public void Destroy()
        {
            try
            {
                Bitvise.Kill();
            }
            catch (Exception ex)
            { }
        }
    }
}
