﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using HitleapExchange.BO;
using System.Threading;
namespace HitleapExchange.DAO
{
   class ProxyDAO
    {
        public static List<string> lstProxy = new List<string>();
        public void GetProxyStelthy()
        {
            string url = "http://rcp.stealthy.co/GetProxy";
            RequestHelper r = new RequestHelper();
            r.CreateRequest(url);
            string respone = r.GetRequest();
            dynamic objProxys = JsonConvert.DeserializeObject(respone);
            foreach (dynamic obj in objProxys)
            {
                string result = obj.host + ":" + obj.port;
                lstProxy.Add(result);
            }
        }
        private void getCoolproxy(int page = 0)
        {
            string bssResponse = "192.168.1.1:88";
            try
            {
                string url = "http://www.cool-proxy.net/proxies/http_proxy_list/sort:score/direction:desc";
                if (page != 0)
                    url += "/page:" + page.ToString();
                RequestHelper r = new RequestHelper();
                r.CreateRequest(url);
                bssResponse = r.GetRequest();
                int p1 = 0, p2 = 0, p3 = 0;
                string host, port;
                string part1 = "document.write(Base64.decode(", part2 = "<td>";
                while ((p1 = bssResponse.IndexOf(part1, p1)) > 0)
                {
                    p1 = p1 + part1.Length + 1;
                    p2 = bssResponse.IndexOf("))", p1);
                    host = bssResponse.Substring(p1, p2 - p1 - 1);
                    host = Encoding.UTF8.GetString(Convert.FromBase64String(host));
                    p2 = bssResponse.IndexOf(part2, p2);
                    p2 = p2 + part2.Length;
                    p3 = bssResponse.IndexOf("</td>", p2);
                    port = bssResponse.Substring(p2, p3 - p2);
                    lstProxy.Add(host + ":" + port);
                }

            }
            catch (Exception)
            {
                throw;
            }
        }
        private void getProxyElut(int page)
        {
            String url = "http://letushide.com/protocol/http/" + page.ToString() + "/list_of_free_HTTP_proxy_servers";
            string bssResponse = "";
            try
            {
                RequestHelper r = new RequestHelper();
                r.CreateRequest(url);
                bssResponse = r.GetRequest();
                Regex regex = new Regex(@"\d{1,3}.\d{1,3}.\d{1,3}.\d{1,3}</a></td><td>\d{1,6}");
                Match match = regex.Match(bssResponse);
                List<string> lstMatch = new List<string>();
                int i = 0;
                while (match.Success)
                {
                    lstProxy.Add(match.Value.Replace("</a></td><td>", ":"));
                    match = match.NextMatch();
                }
            }
            catch(Exception)
            {
                throw;
            }

        }
        public static object objLock = "";
        public bool isFullProxy = false;
        public void getProxyFromServer()
        {
            while (true)
            {
                Random r = new Random();
                GetProxyStelthy();
                getCoolproxy(r.Next(0, 10));
                getProxyElut(r.Next(1, 10));
                while (lstProxy.Count > HLConstant.MAX_COUNT_PROXY)
                {
                    isFullProxy = true;
                    Thread.Sleep(1000);
                }
            }
        }
        public string getProxy()
        {
            lock (objLock)
            {
                string s= lstProxy[0];
                lstProxy.RemoveAt(0);
                return s;
            }
        }
    }
}
