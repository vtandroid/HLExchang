﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using HitleapExchange.BO;
using System.IO;

namespace HitleapExchange.DAO
{
    class RequestHelper
    {
        public string url = "";
        public HttpWebRequest rq;
        public CookieContainer cookieContainerNew = new CookieContainer();
        public WebRequestConfig webRequestConfig;
        public string strWebHeaderConfig = null;
        public string data = "";
        public void setDataRequest(string data)
        {
            try
            {
                this.data = data;
            }
            catch (Exception) { throw; }
        }
        public void setWebRequestConfig(WebRequestConfig w)
        {
            try
            {
                webRequestConfig = w;
            }
            catch (Exception) { throw; }
        }
        public void CreateRequest(string url)
        {
            try
            {
                rq = (HttpWebRequest)WebRequest.Create(url);
                if(webRequestConfig!=null)
                ConfigRequest();
                ConfigRequestNew();
            }
            catch (Exception)
            {
                throw;
            }
        }
        public string GetRequest()
        {
            string bssResponse = "";
            rq.Method = "GET";
             try
             {
                 HttpWebResponse rp = (HttpWebResponse)rq.GetResponse();
                 using (var response = rp)
                 {
                     using (var reader = new StreamReader(response.GetResponseStream()))
                     {
                         bssResponse = reader.ReadToEnd();
                     }
                 }
             }
             catch(Exception ex)
             {
                 throw;
                 //proxy die
             }
             return bssResponse;
                    
        }
        public string PostRequest(string data)
        {
            this.data = data;
            rq.Method = "POST";
            byte[] dataStream = Encoding.UTF8.GetBytes(data);
            rq.ContentLength = dataStream.Length;
            string bssResponse = null;
                try
                {
                    Stream newStream;
                    using (newStream = rq.GetRequestStream())
                    {
                        newStream.Write(dataStream, 0, dataStream.Length);

                    }
                    newStream.Close();
                    HttpWebResponse rp = (HttpWebResponse)rq.GetResponse();
                    using (var response = rp)
                    {
                        using (var reader = new StreamReader(response.GetResponseStream()))
                        {
                            bssResponse = reader.ReadToEnd();
                        }
                    }

                }
                catch (Exception ex)
                {
                    //proxy die
                    throw;
                }
            return bssResponse;
        }
        void ConfigRequestNew()
        {
            rq.CookieContainer = cookieContainerNew;
            if (strWebHeaderConfig != null)
            {
                string[] headerArr = strWebHeaderConfig.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);
                foreach (string item in headerArr)
                {
                    try
                    {
                        string[] itemArr = item.Split(new string[] { ":=" }, StringSplitOptions.None);
                        switch (itemArr[0])
                        {
                            case "User-Agent": rq.UserAgent = itemArr[1]; break;
                            case "Accept": rq.Accept = itemArr[1]; break;
                            case "Content-Type": rq.ContentType = itemArr[1]; break;
                            default: rq.Headers[itemArr[0]] = itemArr[1]; break;
                        }
                        
                    }
                    catch
                    { }
                }
            }
        }
        void ConfigRequest()
        {
            try
            {
                rq.Method = webRequestConfig.method;
                rq.Accept = webRequestConfig.Accept;
                rq.UserAgent = webRequestConfig.UserAgent;

                rq.Headers["Hitleap-Viewer-Os-Version"] = webRequestConfig.HitleapViewerOsVersion;
                rq.Headers["Hitleap-Viewer-Version"] = webRequestConfig.HitleapViewerVersion;
                if(webRequestConfig.AcceptLanguage!=null)
                    rq.Headers["Accept-Language"] = webRequestConfig.AcceptLanguage;

                //Encoding Erroring
                // rq.Headers["Accept-Encoding"] = webRequestConfig.AcceptEncoding;
                if(webRequestConfig.AcceptCharset!=null)
                    rq.Headers["Aceept-Charset"] = webRequestConfig.AcceptCharset;
                if (webRequestConfig.Origin != null)
                {
                    rq.Headers["Origin"] = webRequestConfig.Origin;
                }
                if (webRequestConfig.proxy != null)
                {
                    WebProxy myProxy = new WebProxy(webRequestConfig.proxy);
                    rq.Proxy = myProxy;
                }
                if (webRequestConfig.XCSRFToken != null)
                {
                    rq.Headers["X-CSRF-Token"] = webRequestConfig.XCSRFToken;
                }
                if (webRequestConfig.XRequestedWith != null)
                {
                    rq.Headers["X-Requested-With"] = webRequestConfig.XRequestedWith;
                }
                if (webRequestConfig.HitleapUsername != null)
                {
                    rq.Headers["Hitleap-Username"] = webRequestConfig.HitleapUsername;
                }
                if (webRequestConfig.ContentType != null)
                {
                    rq.ContentType = webRequestConfig.ContentType;
                }
                rq.CookieContainer = webRequestConfig.cookieContainer;
            }
            catch (Exception)
            { throw; }
        }
    }
}
