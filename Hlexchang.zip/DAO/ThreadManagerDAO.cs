﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using HitleapExchange.BO;
namespace HitleapExchange.DAO
{
    class ThreadManagerDAO
    {
        public ProxyDAO proxyDAO;
        Thread threadGetProxy;
        List<HitLeapBO> lstHileapBO;
        BitviseSSHManager bit;
        public static HitleapDAO[] arrHileapDao=null;
        void RunWhenReady()
        {
            while (!bit.isReady)
                Thread.Sleep(1000);
            arrHileapDao = new HitleapDAO[lstHileapBO.Count];
            for (int i = 0; i < lstHileapBO.Count; i++)
            {
                arrHileapDao[i] = new HitleapDAO(lstHileapBO[i]);
                arrHileapDao[i].indexReset = i;
                Thread t = new Thread(arrHileapDao[i].Run);
                t.Start();
               Thread.Sleep(500);
            }
        }
        public ThreadManagerDAO()
        {
            //proxyDAO=new ProxyDAO();
            //threadGetProxy = new Thread(proxyDAO.getProxyFromServer);
            //threadGetProxy.Start();
            AceptAndSave aceptandsave=new AceptAndSave();
            Thread threadClickAcept = new Thread(AceptAndSave.ClickButtonLabeledNo);
            threadClickAcept.Start();
            InfoDAO info = new InfoDAO();
            lstHileapBO = info.GetDataHitleapForSSHFolder();

            bit = BitviseSSHManager.getInstance();
            bit.countBitvise = lstHileapBO.Count;
            Thread tt = new Thread(bit.CreateBitvise);
            tt.Start();
            Thread threadRunWhenReady = new Thread(RunWhenReady);
            threadRunWhenReady.Start();

        }
       
    }
}
