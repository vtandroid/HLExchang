﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HitleapExchange.BO;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using System.Web;
using System.Threading;

namespace HitleapExchange.DAO
{
    class HitleapDAO
    {
        RequestHelper requestHelper = new RequestHelper();
        WebRequestConfig webRequestConfig = new WebRequestConfig();
        public LogDAO logDAO = new LogDAO();
        public HitLeapBO hitleapBO;
        string tokenValue = "";
        public int indexReset = 0;
        public void setDefaultConfig(Boolean isDefault)
        {
            try
            {
                if (isDefault)
                {
                    hitleapBO.webRequestConfig.Origin = HLConstant.URL_HOME;
                    hitleapBO.webRequestConfig.XCSRFToken = null;
                    hitleapBO.webRequestConfig.XRequestedWith = null;
                    hitleapBO.webRequestConfig.Referer = HLConstant.URL_LOGIN;
                    hitleapBO.webRequestConfig.HitleapUsername = null;
                }
                else
                {
                    hitleapBO.webRequestConfig.Origin = null;
                    hitleapBO.webRequestConfig.XCSRFToken = tokenValue;
                    hitleapBO.webRequestConfig.XRequestedWith = HLConstant.XRequestedWith;
                    hitleapBO.webRequestConfig.Referer = HLConstant.URL_REFER;
                    hitleapBO.webRequestConfig.HitleapUsername = hitleapBO.username;
                }
            }
            catch (Exception ex)
            {
                logDAO.LogError("[Error][setDefaultConfig]: " + ex.Message);
                throw; 
            }
        }
        public Boolean Login()
        {
            //Get Token to Login
            string tokenParam = "";
            string respone = "";
            try
            {
                setDefaultConfig(true);
                requestHelper.CreateRequest(HLConstant.URL_LOGIN);
                respone = requestHelper.GetRequest();
                Regex regex = new Regex(@"<meta.*>\B");
                Match m = regex.Match(respone);

             
                while (m.Success)
                {

                    if (m.Value.IndexOf("csrf-token") >= 0)
                    {
                        tokenValue = m.Value.Substring(m.Value.IndexOf("content=\""));
                        tokenValue = tokenValue.Replace("content=\"", "");
                        tokenValue = tokenValue.Substring(0, tokenValue.IndexOf("\""));

                    }
                    if (m.Value.IndexOf("csrf-param") >= 0)
                    {
                        tokenParam = m.Value.Substring(m.Value.IndexOf("content=\""));
                        tokenParam = tokenParam.Replace("content=\"", "");
                        tokenParam = tokenParam.Substring(0, tokenParam.IndexOf("\""));

                    }
                    m = m.NextMatch();
                }
            }
            catch (Exception ex)
            {
                logDAO.LogError("[Error][Get Login Token]: " + ex.Message);
                return false;
            }
            // Send request Login
            try
            {
                string data = @"utf8=%E2%9C%93&" + tokenParam + "=" + HttpUtility.UrlEncode(tokenValue) + "&identifier=" + hitleapBO.username + "&password=" + hitleapBO.password + "&requested_path=%2Ftraffic-exchange";
                requestHelper.CreateRequest(HLConstant.URL_SENDLOGIN);
                respone = requestHelper.PostRequest(data);
            }
            catch (Exception ex)
            {
                logDAO.LogError("[Error][Send Request Login]: " + ex.Message);
                return false;
            }
            return true;

        }
        public Boolean Exchange()
        {
            try
            {
                setDefaultConfig(false);
                requestHelper.CreateRequest(HLConstant.URL_CHUNK);
                string respone = requestHelper.PostRequest(HLConstant.DATA_CHUNK);
                while (respone.IndexOf("{\"code\":\"enqueued\"}") >= 0)
                {
                    requestHelper.CreateRequest(HLConstant.URL_CHUNK);
                    respone = requestHelper.PostRequest(HLConstant.DATA_CHUNK);
                }
                dynamic obj = JsonConvert.DeserializeObject(respone);
                try
                {
                    logDAO.logEarn = obj.session_minutes_earned;
                    logDAO.logPenza = obj.penalized;
                }
                catch (Exception ex)
                {
                    logDAO.LogError("[Error][Convert Json HileapDAO]: " + ex.Message);
                }
                dynamic websites = obj.nn.websites;
                List<WebSiteSurf> lstWebSite = new List<WebSiteSurf>();
                int totalTime = 0;
                foreach (dynamic web in websites)
                {
                    try
                    {
                        WebSiteSurf w = new WebSiteSurf();
                        w.address = web.address;
                        w.timer = web.timer;
                        Thread.Sleep(w.timer * 1000);
                        hitleapBO.webRequestConfig.Referer = HLConstant.URL_REFER;
                        requestHelper.CreateRequest(w.address);
                        respone = requestHelper.GetRequest();
                        if (respone.IndexOf("/clk-css.css?hash=") >= 0)
                        {
                            hitleapBO.webRequestConfig.Referer = w.address;
                            int startIndex = respone.IndexOf("/clk-css.css?hash=");
                            respone = respone.Substring(startIndex);
                            string adrr = respone.Substring(0, respone.IndexOf("'"));
                            adrr = "http://rewee.info" + adrr;
                            requestHelper.CreateRequest(adrr);
                            requestHelper.GetRequest();
                        }
                    }
                    catch (Exception ex)
                    {
                        logDAO.LogError("[Warning][Foreach Website]: " + ex.Message);
                    }
                }

            }
            catch (Exception ex)
            {
                logDAO.LogError("[Error][Exchange]: " + ex.Message);
                return false;
            }
            logDAO.countReset = 0;
            return true;
            
        }
        public void Run()
        {
            Thread.Sleep(1000);
            if (Login())
                RunExchange();
            else
            ResetThread.setResetThread(this);
        }
        public void RunExchange()
        {
            while (Exchange())
            {
                HLConstant.TIMES_TO_RESET++;
            }
            ResetThread.setResetThread(this);
        }
        public string getNode(string source, string tag)
        {
            return "";
        }
        public HitleapDAO(HitLeapBO hitleapBO)
        {
            try
            {
                this.hitleapBO = hitleapBO;
                requestHelper = new RequestHelper();
                //set config for requestWeb default (proxy)
                requestHelper.setWebRequestConfig(hitleapBO.webRequestConfig);//important
            }
            catch (Exception ex)
            {
                logDAO.LogError("[Error][Contructor HileapDAO]: " + ex.Message);
            }

        }
    }
}
