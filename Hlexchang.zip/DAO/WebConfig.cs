﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Threading;
using System.Web;
namespace HitleapExchange.DAO
{
    class WebConfig
    {
        RequestHelperExtend rq = new RequestHelperExtend();
        Hashtable hashtable = new Hashtable();
          
        public void configHeader(string header)
        {
            rq.addHeader(header);
        }
        public void setProxy(string proxy)
        {
            rq.setProxy(proxy);
        }
        public string parseData(string data, string firstKey, string secondKey, bool excluse = true)
        {
            string result = "";
            try
            {
                int indexFirst = data.IndexOf(firstKey);
                if (excluse)
                    indexFirst += firstKey.Length;
                result = data.Substring(indexFirst, data.IndexOf(secondKey, indexFirst) - indexFirst);
            }
            catch { }
            return result;
        }
        public string[] splitData(string data, string key)
        {
            string[] itemArr =new string[0];
            try
            {
                itemArr = data.Split(new string[] { key }, StringSplitOptions.None);
            }
            catch (Exception)
            { }
            return itemArr;
        }
        public void sleepApp(int sleepTime)
        {
            try
            {
                Thread.Sleep(sleepTime*1000);
            }
            catch { }
        }
        public string ifCond(string cond, string a, string b)
        {
            string[] itemArr = cond.Split(new string[] {"=="}, StringSplitOptions.None);
            if ((string)hashtable[itemArr[0]] == itemArr[1])
                return a;
            else
                return b;
        }
        public void Process(string config)
        {
            string[] configArr = config.Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);
            foreach (string item in configArr)
            {
                try
                {

                   
                    // resource:=parseData::data1,,firstVal,,secondVal,,true
                    string[] itemArr = item.Trim().Split(new string[] { ":=" }, StringSplitOptions.None);
                    if (itemArr[1].IndexOf("++") < 0)
                    {
                        string itemFunction = "";
                        string[] itemFunctionArr;
                        if (itemArr[1].IndexOf("parseData") >= 0)
                        {
                             // resource:=parseData::data1,,firstVal,,secondVal,,true
                           itemFunction = itemArr[1].Split(new string[] { "::" }, StringSplitOptions.None)[1];
                           itemFunctionArr= itemFunction.Split(new string[] { ",," }, StringSplitOptions.None);
                           hashtable[itemArr[0]] = parseData((string)hashtable[itemFunctionArr[0]], (string)hashtable[itemFunctionArr[1]], (string)hashtable[itemFunctionArr[2]], bool.Parse((string)hashtable[itemFunctionArr[3]]));
                        }
                        else
                        if (itemArr[1].IndexOf("get_url") >= 0)
                        {
                            // resource:=get_url::url
                            itemFunction = itemArr[1].Split(new string[] { "::" }, StringSplitOptions.None)[1];
                            hashtable[itemArr[0]] = get_url((string)hashtable[itemFunction]);
                        }
                        else
                        if (itemArr[1].IndexOf("post_url") >= 0)
                        {
                            // resource:=post_url::url,,data
                            itemFunction = itemArr[1].Split(new string[] { "::" }, StringSplitOptions.None)[1];
                            itemFunctionArr = itemFunction.Split(new string[] { ",," }, StringSplitOptions.None);
                            hashtable[itemArr[0]] = post_url((string)hashtable[itemFunctionArr[0]], (string)hashtable[itemFunctionArr[1]]);
                        }
                        else
                            if (itemArr[1].IndexOf("splitData") >= 0)
                            {
                                // resource:=post_url::url,,data
                                itemFunction = itemArr[1].Split(new string[] { "::" }, StringSplitOptions.None)[1];
                                itemFunctionArr = itemFunction.Split(new string[] { ",," }, StringSplitOptions.None);
                                hashtable[itemArr[0]] = splitData((string)hashtable[itemFunctionArr[0]], (string)hashtable[itemFunctionArr[1]]);
                            }
                        else
                            if (itemArr[1].IndexOf("arr_") >= 0)
                            {
                                string[] itemFunctions = itemArr[1].Split(new string[] { "::" }, StringSplitOptions.None);
                                string[] tmp=(string[]) hashtable[itemFunctions[0]];
                                hashtable[itemArr[0]] = tmp[int.Parse(itemFunctions[1])];
                            }
                            else
                                if (itemArr[1].IndexOf("ifCond") >= 0)
                                {
                                    itemFunction = itemArr[1].Split(new string[] { "::" }, StringSplitOptions.None)[1];
                                    itemFunctionArr = itemFunction.Split(new string[] { ",," }, StringSplitOptions.None);
                                    hashtable[itemArr[0]] = ifCond((string)itemFunctionArr[0], (string)hashtable[itemFunctionArr[1]], (string)hashtable[itemFunctionArr[2]]);
                                }
                                else
                                    if (itemArr[1].IndexOf("url_encode") >= 0)
                                    {
                                        itemFunction = itemArr[1].Split(new string[] { "::" }, StringSplitOptions.None)[1];
                                        hashtable[itemArr[0]] = HttpUtility.UrlEncode((string)hashtable[itemFunction]);
                                    }
                                    else
                                if (itemArr[1].IndexOf("sleepApp") >= 0)
                                {
                                    itemFunction = itemArr[1].Split(new string[] { "::" }, StringSplitOptions.None)[1];
                                    sleepApp(int.Parse((string)hashtable[itemFunction]));
                                }
                                else
                                hashtable[itemArr[0]] = itemArr[1];
                    }
                    else
                    {
                       string[] itemPlus = itemArr[1].Split(new string[] { "++"}, StringSplitOptions.None);
                       foreach (string itemx in itemPlus)
                       {
                           hashtable[itemArr[0]] =(string) hashtable[itemArr[0]] + (string) hashtable[itemx];
                       }
                    }
                }
                catch
                { }
            }
        }

        public string get_url(string url)
        {
            string result = "";
            rq.CreateRequest(url);
            result=rq.GetRequest();
            return result;
        }
        public string post_url(string url, string data)
        {
            string result = "";
            rq.CreateRequest(url);
            result = rq.PostRequest(data);
            return result;
        }
    }
}
