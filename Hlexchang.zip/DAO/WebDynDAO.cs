﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HitleapExchange.BO;
namespace HitleapExchange.DAO
{
    class WebDynDAO
    {
        RequestHelper requestHelper = new RequestHelper();
        string keyPub = "";
        string rdiPub = "";
        string rvPub = "";
        int firstIndex = 0;
        int secondIndex = 0;
        string temp = "";
        public Boolean Login()
        {
            //get key and Rdi
            WebRequestConfig weRequestConfig=new WebRequestConfig();
            weRequestConfig.XRequestedWith="XMLHttpRequest";
            weRequestConfig.ContentType="application/x-www-form-urlencoded; charset=UTF-8";
            requestHelper.setWebRequestConfig(weRequestConfig);

            //string url = "http://www.websyndic.com/wv3/?p=surf01&0upPrR9KB7FAGmboXK7EuAxZDTp1eZSfUH5LkFgwMw6cihQG2TUxiRWwwLxawQGRhMnSbUOyQUaAC2QFavCJNkGK6Ew3eDUNZIqBnFAEklOxoqCPlPk990UGEQJudoHE78QuNa98MX5ANHZ9hJJrKo7ZFRTuFm8MvTHI9QQWzVgMoHWVbqNweVVux0oDmwagVs0fJRCIyufnCCIo2gkgCGbAGPN3MzltslTBDmUBgAytMHgOyR6BhiLz8k=T34qmmmtut2BOtOKnUVmNcHEOH3DJRmoVqdHbPBVJDhi663uaZfzCyEaFIoZkaNFQ1X3RiTlxHT4NWyz6ezJcEusWiRHJqXks6oJqM5neTr36q3DU3W7HQ0p9S6TIeEAl2UaPZN49F7F6BTaE1hVSiLbBS6U7KesMATmksrt7z9DAdpPeXw7GHkSkrxsBclTnELW6CQECaSMFHnupi260nTldVcq9NOwckTixvy9VQWliJfT2if3WEoAlQ";
            //requestHelper.CreateRequest(url);
            //string response1 = requestHelper.GetRequest();

            requestHelper.CreateRequest(WebDyncConstant.URL_GET_RDI_LOGIN);
            string response = requestHelper.GetRequest();
            firstIndex= response.IndexOf("var key=");
            temp=response.Substring(firstIndex,response.IndexOf(";",firstIndex)-firstIndex);
            keyPub = temp.Replace("var key=", "");
            firstIndex = response.IndexOf("var rdi=\"");
            temp = response.Substring(firstIndex, response.IndexOf("\";", firstIndex) - firstIndex);
            rdiPub=temp.Replace("var rdi=\"","");
            //login 1
            string dataLogin1 = "key=" + keyPub + "&target=login&rdi=" + rdiPub + "&login=getmoneykhmt3@gmail.com&pass=kiemtienthoi&ol=&op=&sh=829&sw=1509";
            requestHelper.CreateRequest(WebDyncConstant.URL_LOGIN_1);
            response = requestHelper.PostRequest(dataLogin1);
            //login 2
            string dataLogin2 = "login_email=getmoneykhmt3%40gmail.com&log_email=&login_passwd=kiemtienthoi&log_passwd=";
            requestHelper.CreateRequest(WebDyncConstant.URL_LOGIN_2);
            response=requestHelper.PostRequest(dataLogin2);
            getEnv();
            return true;
        }
        public Boolean getEnv()
        {
            requestHelper.CreateRequest(WebDyncConstant.URL_GET_LINK_SURF);
            string response= requestHelper.GetRequest();
            firstIndex = response.IndexOf("?p=surf01");
            temp = response.Substring(firstIndex, response.IndexOf("\"", firstIndex) - firstIndex);

            requestHelper.CreateRequest(WebDyncConstant.URL_TARGET);
             requestHelper.GetRequest();

            requestHelper.CreateRequest("http://www.websyndic.com/wv3/" + temp);
            response = requestHelper.GetRequest();

            firstIndex = response.IndexOf("var rv=\"");
            temp = response.Substring(firstIndex, response.IndexOf("\";", firstIndex) - firstIndex);
            rvPub=temp.Replace("var rv=\"","");
            Exchange();
            return true;
        }
        public Boolean Exchange()
        {
            string dataValid = "key="+keyPub+"&w=1.1&rv="+rvPub;
            requestHelper.CreateRequest(WebDyncConstant.URL_VALID_SURF);
            string response = requestHelper.PostRequest(dataValid);
            response = response.Replace("[Spacer]", "|");
            string[] arrStr = response.Split('|');
            return true;
        }
    }
}
