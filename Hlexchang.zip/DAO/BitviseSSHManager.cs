﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Windows.Forms;
using HitleapExchange.BO;
using System.Threading;
namespace HitleapExchange.DAO
{
    class BitviseSSHManager
    {
        InfoDAO infoDAO = new InfoDAO();
        public int countBitvise = 10;
        public int IndexSSH = 0;
        public bool isReady;
        public List<BitviseSSHDAO> lstBitviseSSHDAO;
        List<string> lstSSH;
        public static BitviseSSHManager instance;
        public static BitviseSSHManager getInstance()
        {
            if (instance == null)
                instance = new BitviseSSHManager();
            return instance;
        }
        public BitviseSSHManager()
        {
            isReady = false;
        }
        string c2sConfigAll = "";
        public void CreateBitvise()
        {
            try
            {
                List<string> lstConfigSSH = infoDAO.GetConfigSSHFolder();
                for (int i = 0; i < lstConfigSSH.Count; i++)
                {
                    string[] arrTempC2S = lstConfigSSH[i].Split('|');
                    string c2sConfig = arrTempC2S[0] + "@," + HLConstant.PORT_DEFAULT_PROXY + "," + arrTempC2S[1] + "," + HLConstant.PORT_DEFAULT_WEB;
                    if (c2sConfigAll != "")
                        c2sConfigAll += ",";
                    c2sConfigAll += c2sConfig;
                }

                lstSSH = infoDAO.GetListSSHFromFolder();

                lstBitviseSSHDAO = new List<BitviseSSHDAO>();
                //config
                for (int i = 0; i < countBitvise; i++)
                {
                    BitviseSSHBO bitviseSSHBO = new BitviseSSHBO();
                    string[] arrSSH = lstSSH[IndexSSH++].Split('|');
                    bitviseSSHBO.host = arrSSH[0];
                    bitviseSSHBO.user = arrSSH[1];
                    bitviseSSHBO.pass = arrSSH[2];
                    bitviseSSHBO.c2sConfig = c2sConfigAll.Replace("@", (i + 1).ToString());
                    BitviseSSHDAO bitviseSSHDAO = new BitviseSSHDAO();
                    bitviseSSHDAO.setBitviseSSHBO(bitviseSSHBO);
                    lstBitviseSSHDAO.Add(bitviseSSHDAO);
                }
                //Run
                foreach (BitviseSSHDAO bitviseSSHDAO in lstBitviseSSHDAO)
                {
                    bitviseSSHDAO.CreateBitvise();
                    Thread.Sleep(5000);
                }
            }
            catch (Exception ex)
            { }
            isReady = true;


        }
        object objReset = "";
        public void ResetBitvise(int indexReset)
        {
            try
            {
                lock (objReset)
                {
                    lstBitviseSSHDAO[indexReset].Destroy();
                    //reconfig
                    BitviseSSHBO bitviseSSHBO = new BitviseSSHBO();
                    string[] arrSSH = lstSSH[IndexSSH++].Split('|');
                    bitviseSSHBO.host = arrSSH[0];
                    bitviseSSHBO.user = arrSSH[1];
                    bitviseSSHBO.pass = arrSSH[2];
                    bitviseSSHBO.c2sConfig = lstBitviseSSHDAO[indexReset].bitviseSSHBO.c2sConfig;
                    lstBitviseSSHDAO[indexReset].setBitviseSSHBO(bitviseSSHBO);
                    lstBitviseSSHDAO[indexReset].CreateBitvise();
                }
            }
            catch (Exception ex)
            {
                IndexSSH = 0;
            }
        }
    }
}
